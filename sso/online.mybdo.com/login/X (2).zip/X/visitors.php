<?php
$file = "magicaltext.txt"; 
$no_of_lines = count(file($file));
echo $no_of_lines;
?>
